import cPickle as pickle
import matplotlib.pyplot as pb, numpy as np
import urllib, os
import GPy

model_path =  './bgplvm_rbf.pickle'
if not os.path.exists(model_path):
	urllib.urlretrieve('http://staffwww.dcs.sheffield.ac.uk/people/J.Hensman/digit_bgplvm_demo.pickle', model_path)
with open('./bgplvm_rbf.pickle','r') as f:
    m = pickle.load(f)
which = [0,3,6,7,8,9]
num_samples = 55
labels = np.array([[str(l)]*num_samples for l in which])

fig = pb.figure('Latent Space & Scales', figsize=(16,6))
ax_latent = fig.add_subplot(121)
ax_scales = fig.add_subplot(122)

fig_out = pb.figure('Output', figsize=(1,1))
ax_image  = fig_out.add_subplot(111)
ax_image.set_xticks([]); ax_image.set_yticks([])
fig_out.tight_layout(pad=0)

m.plot_latent(which_indices=(0, 1), labels=labels.flatten(), ax=ax_latent)

data_show = GPy.util.visualize.image_show(m.likelihood.Y[0:1, :], dimensions=(16, 16), transpose=1, invert=0, scale=False, axes=ax_image)
lvm_visualizer = GPy.util.visualize.lvm_dimselect(m.X[0, :].copy(), m, data_show, ax_latent, ax_scales, labels=labels.flatten())

raw_input("Enter to exit")